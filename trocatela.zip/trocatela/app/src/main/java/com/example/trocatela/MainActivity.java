package com.example.trocatela;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    Button enviar;
    EditText nome, sobrenome;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        enviar = findViewById(R.id.enviar);
        nome = findViewById(R.id.nome);
        sobrenome = findViewById(R.id.sobrenome);

        enviar.setOnClickListener(v -> {
            String str = nome.getText().toString();
            Intent intent = new Intent(getApplicationContext(), resposta.class);
            intent.putExtra("message_key", str);
            startActivity(intent);

    });
}
}

